# دليل نشر عملة ISLAMIC SHIELD (DER) على شبكة TON

هذا الدليل يشرح خطوات نشر عملة ISLAMIC SHIELD (DER) على شبكة TON باستخدام GitHub.

## المتطلبات المسبقة

1. حساب GitHub
2. محفظة TON تحتوي على رصيد كافٍ (حوالي 1 TON على الأقل)
3. Node.js و npm مثبتان على جهازك
4. Git مثبت على جهازك

## خطوات النشر

### 1. إنشاء مستودع GitHub

1. قم بتسجيل الدخول إلى حسابك على [GitHub](https://github.com)
2. انقر على زر "+" في الزاوية العلوية اليمنى واختر "New repository"
3. أدخل اسم المستودع (مثلاً: `islamic-shield-token`)
4. اختر "Public" أو "Private" حسب تفضيلاتك
5. انقر على "Create repository"

### 2. استنساخ المستودع محلياً

```bash
git clone https://github.com/YOUR_USERNAME/islamic-shield-token.git
cd islamic-shield-token
```

### 3. استخراج ملفات المشروع

1. قم بتنزيل الحزمة المضغوطة (`islamic-shield-token.zip`) التي تم توفيرها
2. استخرج محتويات الحزمة إلى مجلد المستودع المحلي

### 4. رفع شعار العملة

1. قم بإنشاء مستودع GitHub جديد باسم `website` (أو أي اسم آخر تفضله)
2. قم بتمكين GitHub Pages لهذا المستودع:
   - انتقل إلى "Settings" > "Pages"
   - اختر "main" كمصدر
   - انقر على "Save"
3. قم برفع ملف الشعار (`logo.png`) إلى هذا المستودع
4. بعد النشر، سيكون رابط الشعار متاحاً على:
   `https://YOUR_USERNAME.github.io/website/logo.png`
5. قم بتحديث رابط الشعار في ملف `token-config.js`:
   ```javascript
   image: "https://YOUR_USERNAME.github.io/website/logo.png",
   ```

### 5. تثبيت التبعيات

```bash
cd minter-contract
npm install
```

### 6. تكوين العقود الذكية

1. تأكد من أن ملفات العقود الذكية المعدلة موجودة في المجلد `contracts`:
   - `jetton-wallet-modified.fc`
   - `jetton-minter-modified.fc`

2. تأكد من أن ملفات التكوين موجودة في المجلد `build`:
   - `token-config.js`
   - `deploy-config.js`

### 7. إنشاء ملف النشر

قم بإنشاء ملف `deploy.js` في المجلد الرئيسي للمشروع:

```javascript
const { JettonParams, customContracts } = require('./build/deploy-config');
const { Address } = require('@ton/core');
const fs = require('fs');
const path = require('path');

// تحميل العقود المعدلة
const jettonMinterCode = fs.readFileSync(path.resolve(customContracts.jettonMinter), 'utf8');
const jettonWalletCode = fs.readFileSync(path.resolve(customContracts.jettonWallet), 'utf8');

async function deployJetton() {
  console.log('بدء نشر عملة ISLAMIC SHIELD (DER)...');
  
  // هنا يتم إضافة كود النشر الفعلي
  // يمكن استخدام مكتبة @ton/core للتفاعل مع شبكة TON
  
  console.log('تم نشر العملة بنجاح!');
  console.log('عنوان العقد الرئيسي:', '...'); // سيتم تحديثه بعد النشر
}

deployJetton().catch(console.error);
```

### 8. نشر العملة على شبكة TON التجريبية (للاختبار)

1. قم بتعديل ملف `deploy.js` لاستخدام شبكة TON التجريبية:

```javascript
// إضافة إلى ملف deploy.js
const { TonClient } = require('@ton/ton');

// إعداد اتصال بشبكة TON التجريبية
const client = new TonClient({
  endpoint: 'https://testnet.toncenter.com/api/v2/jsonRPC',
  apiKey: 'YOUR_TONCENTER_API_KEY' // احصل على مفتاح API من https://t.me/tontestnetapibot
});
```

2. قم بتنفيذ النشر:

```bash
node deploy.js
```

### 9. نشر العملة على الشبكة الرئيسية

1. قم بتعديل ملف `deploy.js` لاستخدام الشبكة الرئيسية:

```javascript
// إضافة إلى ملف deploy.js
const { TonClient } = require('@ton/ton');

// إعداد اتصال بالشبكة الرئيسية
const client = new TonClient({
  endpoint: 'https://toncenter.com/api/v2/jsonRPC',
  apiKey: 'YOUR_TONCENTER_API_KEY' // احصل على مفتاح API من https://t.me/tonapibot
});
```

2. قم بتنفيذ النشر:

```bash
node deploy.js
```

### 10. رفع التغييرات إلى GitHub

```bash
git add .
git commit -m "نشر عملة ISLAMIC SHIELD (DER)"
git push origin main
```

## بعد النشر

بعد نشر العملة بنجاح، ستحتاج إلى:

1. **توثيق عنوان العقد الرئيسي**: احتفظ بعنوان العقد الرئيسي للعملة للرجوع إليه في المستقبل.

2. **إضافة العملة إلى محفظتك**: يمكنك إضافة العملة إلى محفظة TON مثل Tonkeeper أو Tonhub باستخدام عنوان العقد الرئيسي.

3. **مراقبة العمليات**: يمكنك مراقبة عمليات العملة باستخدام مستكشف TON مثل [tonscan.org](https://tonscan.org).

4. **تحديث الوثائق**: قم بتحديث وثائق المشروع بمعلومات النشر والعناوين الفعلية.

## استكشاف الأخطاء وإصلاحها

إذا واجهت أي مشاكل أثناء النشر، تحقق من:

1. **رصيد المحفظة**: تأكد من أن محفظتك تحتوي على رصيد كافٍ من TON.

2. **صحة العناوين**: تأكد من صحة جميع العناوين المستخدمة في ملفات التكوين.

3. **سجلات الأخطاء**: تحقق من سجلات الأخطاء للحصول على معلومات حول أي مشاكل.

4. **إصدارات المكتبات**: تأكد من استخدام الإصدارات المتوافقة من مكتبات TON.

## موارد إضافية

- [وثائق TON الرسمية](https://docs.ton.org)
- [مستكشف TON](https://tonscan.org)
- [مجتمع TON على Telegram](https://t.me/tondev)
